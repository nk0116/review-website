<link rel="stylesheet" href="commons/mailform.css" type="text/css" />
<link rel="stylesheet" href="commons/bug.css" type="text/css" />
<script type="text/javascript" src="commons/jquery.js" charset="UTF-8"></script>
<script type="text/javascript" src="commons/mailform.js" charset="UTF-8"></script>
<script type="text/javascript" src="postcodes/get.cgi?js" charset="UTF-8"></script>
<!-- InstanceEndEditable --><!--idcontents fin-->
</div>

<div class="clearfix pc_only">
<br />
<br />
<br />
<br />
</div>
</div><!--idmain fin-->
</div><!--idwrap_main fin-->
<?php include '../config/footer.php'; ?>
<script type='text/javascript' src='//ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js'></script>
<script type="text/javascript" src='../js/config.js'></script>
</body>
<!-- InstanceEnd -->
</html>
