<!--
if(document.referrer.indexOf(document.domain) == -1){
	document.cookie = "mfp_referrer=" + escape(document.referrer) + "; path=/; expires=";
}
//-->