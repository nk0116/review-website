﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <!-- <title>学校成績保証の個別指導塾 レビュー</title> -->
     <!-- 拡張子をhtmlに必ず治す -->
    <title>レビューローカル</title>
    <!-- 直してからアップ -->

    <meta name="keywords" content="個別指導,受験,学習塾,受験対策,進路指導,岡山,総社市,成績保証,最安値" />
    <meta name="description" content="総社駅前に新規開校！個別指導レビューは学校のテスト対策に特化した「先生1人に生徒2名の完全個別指導塾」" />
    <meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no" />
    <link rel="”icon”" href="../favicon.ico" />
    <link href="css/base.css" rel="stylesheet" type="text/css" />
    <link href="css/top.css" rel="stylesheet" type="text/css" />
    <link href="css/content.css" rel="stylesheet" type="text/css" />
    <link href="css/basestyle.css" rel="stylesheet" type="text/css" />
    <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js" defer></script>
    <script type="text/javascript" src="js/config.js" defer></script>
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-195019416-1"></script>
    <script>
      window.dataLayer = window.dataLayer || [];

      function gtag() {
        dataLayer.push(arguments);
      }
      gtag("js", new Date());

      gtag("config", "UA-195019416-1");
    </script>
    <meta name="google-site-verification" content="oPjcYR5ZnD0D5WGD100vGzDWgBDJOOzCzRsG3VQ1nik" />
  </head>

  <body>
    <?php $nowPage="top"; include 'config/header.php';?>
    <div id="top_wrap" class="">
      <div id="topimg" class="">
        <br />
        <picture>
          <source media="(min-width: 768px)" srcset="images/2017topimg.jpg" />
          <!--PC画像-->
          <source media="(max-width: 768px)" srcset="images/2017topimgSp.jpg" />
          <!--SP画像-->
          <img
            src="images/2017topimg.jpg"
            alt="新規開校！新規入学生募集！「分からない、できない」は大歓迎です！個別指導レビューは大手個別指導塾で長年培ってきた経験と実績から生まれた個別指導システムです。"
            width="950"
            height="391"
          />
        </picture>
      </div>
    </div>
    <br />
    <div id="main" class="">
      <!--sidenav-->
      <?php include 'config/sidebar.php'; ?>
      <!--maincontent-->
      <div class="sp_only spaddtopCampaign">
        <h2 class="h2topCampaign">【個別指導レビューを動画で見る】</h2>
        <div class="youtubeCampaign">
          <iframe
            width="560"
            height="315"
            src="https://www.youtube.com/embed/q0jem3r4L6Q?si=5FXgbG8GxDK2zTNi"
            title="YouTube video player"
            frameborder="0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
            referrerpolicy="strict-origin-when-cross-origin"
            allowfullscreen
          ></iframe>
        </div>

        <div class="bnrYoutubeBtmLxn">
          <figure class="bnrYoutubeBtmPic">
            <picture>
              <source media="(min-width: 768px)" srcset="images/bnrYoutubeBtmPc.jpg" />
              <!--PC画像-->
              <source media="(max-width: 768px)" srcset="images/bnrYoutubeBtmSp.jpg" />
              <!--SP画像-->
              <img src="images/bnrYoutubeBtmPc.jpg" alt="最新情報 " width="680" height="219" />
            </picture>
          </figure>
          <a class="bnrYoutubeBtm" href="https://review-rank.jp/lp/kobetsu-review/?utm_source=homepage&utm_medium=ban" target="_blank"></a>
        </div>
      </div>
      <div id="contents">
        <div class="pc_only">
          <h2 class="h2topCampaign">【個別指導レビューを動画で見る】</h2>
          <div class="youtubeCampaign">
            <iframe
              width="560"
              height="315"
              src="https://www.youtube.com/embed/q0jem3r4L6Q?si=5FXgbG8GxDK2zTNi"
              title="YouTube video player"
              frameborder="0"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
              referrerpolicy="strict-origin-when-cross-origin"
              allowfullscreen
            ></iframe>
          </div>

          <div class="bnrYoutubeBtmLxn">
            <figure class="bnrYoutubeBtmPic">
              <picture>
                <source media="(min-width: 768px)" srcset="images/bnrYoutubeBtmPc.jpg" />
                <!--PC画像-->
                <source media="(max-width: 768px)" srcset="images/bnrYoutubeBtmSp.jpg" />
                <!--SP画像-->
                <img src="images/bnrYoutubeBtmPc.jpg" alt="最新情報 " width="680" height="219" />
              </picture>
            </figure>
            <a class="bnrYoutubeBtm" href="https://review-rank.jp/lp/kobetsu-review/?utm_source=homepage&utm_medium=ban" target="_blank"></a>
          </div>
        </div>

        <style>
          .h2topCampaign {
            color: #000;
            text-align: center;
            leading-trim: both;
            text-edge: cap;
            font-family: "Noto Sans JP";
            font-size: 20px;
            font-style: normal;
            font-weight: 400;
            line-height: normal;
          }

          .youtubeCampaign {
            aspect-ratio: 681 / 383;
            position: relative;
            margin: 20px 0 0 0;
          }

          .youtubeCampaign iframe {
            position: absolute;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
          }

          .bnrYoutubeBtmLxn {
            margin: 20px 0 20px 0;
            position: relative;
          }

          .bnrYoutubeBtmPic {
            margin: 0;
            padding: 0;
          }

          .bnrYoutubeBtm {
            position: absolute;
            display: block;
            width: 358px;
            height: 161px;
            right: 4px;
            bottom: 0;
          }

          @media screen and (max-width: 768px) {
            .spaddtopCampaign {
              width: 88.26666666666667%;
              margin: auto;
            }

            .spaddtopCampaign img {
              width: 100%;
              height: auto;
            }

            .h2topCampaign {
              color: #000;
              text-align: center;
              leading-trim: both;
              text-edge: cap;
              font-family: "Noto Sans JP";
              font-size: 20px;
              font-style: normal;
              font-weight: 400;
              line-height: normal;
              margin: 0px 0 0 0;
            }

            .youtubeCampaign {
              aspect-ratio: 681 / 383;
              position: relative;
              margin: 20px 0 0 0;
            }

            .youtubeCampaign iframe {
              position: absolute;
              left: 0;
              top: 0;
              width: 100%;
              height: 100%;
            }

            .bnrYoutubeBtmLxn {
              margin: 40px 0 40px 0;
              position: relative;
            }

            .bnrYoutubeBtmPic {
              margin: 0;
              padding: 0;
            }

            .bnrYoutubeBtmPic img {
              display: block;
              height: auto;
            }

            .bnrYoutubeBtm {
              position: absolute;
              display: block;
              width: 92%;
              height: 38%;
              right: 0;
              bottom: 0;
              left: 0;
              margin: auto;
            }
          }
        </style>
        <div class="sentence">
          <div id="title">
            <h2>
              <picture>
                <source media="(min-width: 768px)" srcset="images/ti_new.jpg" />
                <!--PC画像-->
                <source media="(max-width: 768px)" srcset="images/ti_newSp.jpg" />
                <!--SP画像-->
                <img src="images/ti_new.jpg" alt="最新情報 " width="680" height="40" />
              </picture>
            </h2>
          </div>
          <p>
            <picture>
              <source media="(min-width: 768px)" srcset="images/2021news.jpg" />
              <!--PC画像-->
              <source media="(max-width: 768px)" srcset="images/2021newsSp.jpg" />
              <!--SP画像-->
              <img src="images/2021news.jpg" alt="最新情報 " width="636" border="0" />
            </picture>
          </p>
          <h3 class="topCampaign">キャンペーン</h3>
          <p>
            <a href="charge/index.html#tryal">
              <picture>
                <source media="(min-width: 768px)" srcset="images/2017campain.jpg" />
                <!--PC画像-->
                <source media="(max-width: 768px)" srcset="images/2017campainSp.jpg" />
                <!--SP画像-->
                <img src="images/2017campain.jpg" alt="新規開校キャンペーン　最大1ヶ月無料体験！さらに先着20名入会金100％OFF、初月授業料半額！" width="" border="0" />
              </picture>
            </a>
            <br class="pc_only" />
            <br class="pc_only" />
          </p>
          <img class="pc_only" src="images/main_btm.jpg" width="680" height="24" />
        </div>
        <!--sentence fin-->
      </div>
      <!--idcontents fin-->
      <div class="clearfix pc_only">
        <br />
        <br />
        <br />
        <br />
      </div>
    </div>
    <!--    <div class="clearfix pc_only">
    <br>
    <br>
    <br>
    <br>
    </div>-->
    <?php include 'config/footer.php'; ?>
  </body>
</html>
